package edu.quinnipiac.ser210.tictactoe;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/*
 *   Author: Joe Ruiz
 */

public class TicTacToe extends AppCompatActivity implements ITicTacToe {

    // The game board and the game status
    private static final int ROWS = 3, COLS = 3;
    private int[][] board = new int[ROWS][COLS];
    private static int NUM_PLAYS;
    private String name;
    private int[] buttonIDs = {R.id.b1, R.id.b2, R.id.b3, R.id.b4, R.id.b5, R.id.b6, R.id.b7, R.id.b8, R.id.b9};
    private ArrayList<Button> buttons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tictactoe);

        // Player Greeting
        name = getIntent().getStringExtra("name");
        TextView playerGreet = (TextView) findViewById(R.id.Title);
        playerGreet.setShadowLayer(10, 5, 5, Color.BLACK);
        playerGreet.setText("Welcome " + name + "!");

        // Game Buttons
        buttons = new ArrayList<Button>();
        for (int id : buttonIDs) {
            Button button = (Button) findViewById(id);
            buttons.add(button);
        }

        //Restart Button
        Button restartBtn = (Button) findViewById(R.id.restart);
        restartBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                clearBoard();
            }
        });
        //Quit Button
        Button quitBtn = (Button) findViewById(R.id.quit);
        quitBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                finish();
                System.exit(0);
            }
        });

        // Save Progress when flipped called
        if (savedInstanceState != null) {
            this.board = (int[][]) savedInstanceState.getSerializable("Game");
            display();
        } else {

        }

    }

    // Save Progress when flipped
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("Game", board);
    }

    public void onClick(View v) {
        this.setMove(1, buttons.indexOf(findViewById(v.getId())));
        this.setMove(2, this.getComputerMove());
        display();
        checkForWinner();

        // Winner Toast Check
        if (checkForWinner() == TIE) {
            Toast.makeText(TicTacToe.this, "ITS A TIE!!", Toast.LENGTH_LONG).show();
        } else if (checkForWinner() == CROSS_WON) {
            Toast.makeText(TicTacToe.this, "ITS A CROSS WIN!!", Toast.LENGTH_LONG).show();
        } else if (checkForWinner() == NOUGHT_WON) {
            Toast.makeText(TicTacToe.this, "ITS A NOUGHT WIN!!", Toast.LENGTH_LONG).show();
        }

    }


    public void display() {
        int counter = 0;

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                switch (board[row][col]) {
                    case 0:
                        counter++;
                        break;
                    case 1:
                        buttons.get(counter).setBackgroundResource(R.drawable.x);
                        counter++;
                        break;
                    case 2:
                        buttons.get(counter).setBackgroundResource(R.drawable.o);
                        counter++;
                        break;
                }
            }
        }
    }


    @Override
    public void clearBoard() {
        findViewById(R.id.b1).setBackgroundResource(R.drawable.gray);
        findViewById(R.id.b2).setBackgroundResource(R.drawable.gray);
        findViewById(R.id.b3).setBackgroundResource(R.drawable.gray);
        findViewById(R.id.b4).setBackgroundResource(R.drawable.gray);
        findViewById(R.id.b5).setBackgroundResource(R.drawable.gray);
        findViewById(R.id.b6).setBackgroundResource(R.drawable.gray);
        findViewById(R.id.b7).setBackgroundResource(R.drawable.gray);
        findViewById(R.id.b8).setBackgroundResource(R.drawable.gray);
        findViewById(R.id.b9).setBackgroundResource(R.drawable.gray);

        // TODO Auto-generated method stub
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                board[i][j] = EMPTY;
            }
        }
    }

    @Override
    public void setMove(int player, int loc) {
        // TODO Auto-generated method stub
        board[loc / 3][loc % 3] = player;

        NUM_PLAYS++;
    }

    @Override
    public int getComputerMove() {
        // TODO Auto-generated method stub
        int move = (int) (Math.random() * 9);

        while (board[move / 3][move % 3] != EMPTY) {
            move = (int) (Math.random() * 9);
        }
        return move;
    }

    @Override
    public int checkForWinner() {
        // TODO Auto-generated method stub
        if ((board[0][0] == board[0][1]) && (board[0][1] == board[0][2])) {
            if (board[0][0] == 1) {
                return 2;
            } else if (board[0][0] == 2) {
                return 3;
            }
        }
        // Middle row
        if ((board[1][0] == board[1][1]) && (board[1][1] == board[1][2])) {
            if (board[1][0] == 1) {
                return 2;
            } else if (board[1][0] == 2) {
                return 3;
            }
        }

        // Bottom row
        if ((board[2][0] == board[2][1]) && (board[2][1] == board[2][2])) {
            if (board[2][0] == 1) {
                return 2;
            } else if (board[2][0] == 2) {
                return 3;
            }
        }

        // Check verticals

        // Left column
        if ((board[0][0] == board[1][0]) && (board[1][0] == board[2][0])) {
            if (board[0][0] == 1) {
                return 2;
            } else if (board[0][0] == 2) {
                return 3;
            }
        }

        // Middle column
        if ((board[0][1] == board[1][1]) && (board[1][1] == board[2][1])) {
            if (board[0][1] == 1) {
                return 2;
            } else if (board[0][1] == 2) {
                return 3;
            }
        }

        // Right column
        if ((board[0][2] == board[1][2]) && (board[1][2] == board[2][2])) {
            if (board[0][2] == 1) {
                return 2;
            } else if (board[0][2] == 2) {
                return 3;
            }
        }
        // Check diagonals
        // 1
        if ((board[0][0] == board[1][1]) && (board[1][1] == board[2][2])) {
            if (board[0][0] == 1) {
                return 2;
            } else if (board[0][0] == 2) {
                return 3;
            }
        }

        // 2
        if ((board[0][2] == board[1][1]) && (board[1][1] == board[2][0])) {
            if (board[0][2] == 1) {
                return 2;
            } else if (board[0][2] == 2) {
                return 3;
            }
        }
        if (NUM_PLAYS == 8) {
            return 1;
        }
        return 0;
    }

    // Print game board
    public void printBoard() {
        for (int row = 0; row < ROWS; ++row) {
            for (int col = 0; col < COLS; ++col) {
                printCell(board[row][col]); // print each of the cells
                if (col != COLS - 1) {
                    System.out.print("|"); // print vertical partition
                }
            }
            System.out.println();
            if (row != ROWS - 1) {
                System.out.println("-----------"); // print horizontal partition
            }
        }
        System.out.println();
    }

    /**
     * Print a cell with the specified "content"
     *
     * @param content either CROSS, NOUGHT or EMPTY
     */
    public void printCell(int content) {
        switch (content) {
            case EMPTY:
                System.out.print("   ");
                break;
            case NOUGHT:
                System.out.print(" O ");
                break;
            case CROSS:
                System.out.print(" X ");
                break;
        }
    }

}
